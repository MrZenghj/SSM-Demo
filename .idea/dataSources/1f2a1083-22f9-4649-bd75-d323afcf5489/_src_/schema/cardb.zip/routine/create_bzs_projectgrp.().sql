CREATE FUNCTION create_bzs_projectgrp()
  RETURNS VARCHAR(20)
  BEGIN 
	INSERT INTO seq_bzs_projectgrp(`name`) value ('G');  
	RETURN(select concat(`name`,MAX(seq)) id from seq_bzs_projectgrp);
END;
