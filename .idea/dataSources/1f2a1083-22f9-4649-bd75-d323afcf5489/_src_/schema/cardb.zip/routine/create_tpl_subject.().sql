CREATE FUNCTION create_tpl_subject()
  RETURNS VARCHAR(20)
  BEGIN 
	INSERT INTO seq_tpl_subject(`name`) value ('TS');  
	RETURN(select concat(`name`,MAX(seq)) id from seq_tpl_subject);
END;
