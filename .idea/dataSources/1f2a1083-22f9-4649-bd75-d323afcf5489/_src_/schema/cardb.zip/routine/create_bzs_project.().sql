CREATE FUNCTION create_bzs_project()
  RETURNS VARCHAR(20)
  BEGIN 
	INSERT INTO seq_bzs_project(`name`) value ('P');  
	RETURN(select concat(`name`,MAX(seq)) id from seq_bzs_project);
END;
