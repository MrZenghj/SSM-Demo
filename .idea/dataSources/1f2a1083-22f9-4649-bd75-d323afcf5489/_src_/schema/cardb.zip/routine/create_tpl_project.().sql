CREATE FUNCTION create_tpl_project()
  RETURNS VARCHAR(20)
  BEGIN 
	INSERT INTO seq_tpl_project(`name`) value ('TP');  
	RETURN(select concat(`name`,MAX(seq)) id from seq_tpl_project);
END;
