CREATE FUNCTION create_bzs_subject()
  RETURNS VARCHAR(20)
  BEGIN 
	INSERT INTO seq_bzs_subject(`name`) value ('S');  
	RETURN(select concat(`name`,MAX(seq)) id from seq_bzs_subject);
END;
