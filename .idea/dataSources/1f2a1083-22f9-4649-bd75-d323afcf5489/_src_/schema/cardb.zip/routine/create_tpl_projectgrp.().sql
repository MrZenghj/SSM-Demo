CREATE FUNCTION create_tpl_projectgrp()
  RETURNS VARCHAR(20)
  BEGIN 
	INSERT INTO seq_tpl_projectgrp(`name`) value ('TG');  
	RETURN(select concat(`name`,MAX(seq)) id from seq_tpl_projectgrp);
END;
