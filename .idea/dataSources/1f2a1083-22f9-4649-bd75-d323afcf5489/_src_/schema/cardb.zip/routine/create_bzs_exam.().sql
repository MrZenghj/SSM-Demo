CREATE FUNCTION create_bzs_exam()
  RETURNS VARCHAR(20)
  BEGIN 
	INSERT INTO seq_bzs_exam(`name`) value ('E');  
	RETURN(select concat(`name`,MAX(seq)) id from seq_bzs_exam);
END;
