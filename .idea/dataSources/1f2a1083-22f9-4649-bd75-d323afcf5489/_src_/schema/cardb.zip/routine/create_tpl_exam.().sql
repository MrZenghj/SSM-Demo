CREATE FUNCTION create_tpl_exam()
  RETURNS VARCHAR(20)
  BEGIN 
	INSERT INTO seq_tpl_exam(`name`) value ('TE');  
	RETURN(select concat(`name`,MAX(seq)) id from seq_tpl_exam);
END;
